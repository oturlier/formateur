'use strict'

module.exports = (value) => JSON.stringify(value)
